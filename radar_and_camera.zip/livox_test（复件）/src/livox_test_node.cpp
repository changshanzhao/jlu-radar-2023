#include "ros/ros.h"
#include "sensor_msgs/PointCloud2.h"

#include "vector"
#include "queue"
#include "math.h"
#include "algorithm"

#include "pcl/point_cloud.h"
#include "pcl/point_types.h"
#include "pcl/filters/voxel_grid.h"
#include "pcl_conversions/pcl_conversions.h"
#include "utils/ikd_Tree.h"

#include "livox_ros_driver/CustomMsg.h"
#include "livox_ros_driver/CustomPoint.h"

#define layers_per_map  5
#define queue_limit_    10
#define intensity_thresh_1 120.0
#define intensity_thresh_2 175.0

const float_t FOV                   = 70.4;         // 角度制
const uint8_t cloud_num_per_map[]   = {1, 4, 8, 16, 32};    // 每层分的格数
const uint8_t min_index_submap[]    = {0, 1, 5, 13, 29};   // 每层的最小索引
float boundry_tan_yz_x[layers_per_map - 1] = {0};   // 数量为 层数-1, 初始化时对这个数据进行计算
// std::vector<std::vector<float>> tan_y_z;
float boundry_atan_y_z[layers_per_map];

// EVALUATE

struct cloudFrame{
    pcl::PointCloud<pcl::PointXYZI>::Ptr cloud;
    size_t cloud_size;
};

float degree2rad(float d){
    return d * M_PI/ 180.0f;
}

float rad2dgree(float r){
    return r * 180.0f / M_PI;
}

class mapMaintainer{
    public:
        mapMaintainer(std::string topic_name) : nh_("/"), cloud_topic_name_(topic_name){
            init_ros();
            init_params();
            init_pcl();
            record_file_ = fopen("record.csv", "wb+");
            record_file_t_ = fopen("record_t.csv", "wb+");
            // timer = nh_.createTimer ( ros::Duration ( 0.1), &mapMaintainer::check_cloud, this);
        };

        ~mapMaintainer(){
            fclose(record_file_);
            fclose(record_file_t_);
        }
        
        void init_pcl(){
            vox_filter_ = pcl::VoxelGrid<pcl::PointXYZI>::Ptr(new pcl::VoxelGrid<pcl::PointXYZI>);
            map_ = pcl::PointCloud<pcl::PointXYZI>::Ptr(new pcl::PointCloud<pcl::PointXYZI>);
            
            vox_filter_->setLeafSize(0.05f, 0.05f, 0.05f);
            vox_filter_->setInputCloud(map_);
            
            cloud_num_total = 0;
            for(int num : cloud_num_per_map){
                cloud_num_total += num;
            }
            map_list_.resize(cloud_num_total);
            // KD_TREE初始化
            map_list_kd_.resize(cloud_num_total);
            sub_map_buffs_.resize(cloud_num_total);
            for(int i=0; i < cloud_num_total; i++){
                map_list_[i] = pcl::PointCloud<pcl::PointXYZI>::Ptr(new pcl::PointCloud<pcl::PointXYZI>);
                map_list_kd_[i] = KD_TREE<pcl::PointXYZI>::Ptr(new KD_TREE<pcl::PointXYZI>(0.3, 0.6, 0.2));
                sub_map_buffs_[i].clear();
            }
        }

        void init_ros(){
            sub_livox_cloud_ = nh_.subscribe(cloud_topic_name_, 5, &mapMaintainer::cloudLivxoCB, this);
            pub_scan_ = nh_.advertise<sensor_msgs::PointCloud2>("scan", 5);
            pub_map_visual_split_ = nh_.advertise<sensor_msgs::PointCloud2>("map_s", 5);
            // map_timer = nh_.createTimer(ros::Duration ( 0.1), &mapMaintainer::process, this);
            visual_timer = nh_.createTimer(ros::Duration (1), &mapMaintainer::visualThread, this);
        }

        void init_params(){
            float degree_per_layer = FOV / layers_per_map;
            for(size_t k=0; k < layers_per_map - 1; k++){
                boundry_tan_yz_x[k] = tan(degree2rad(degree_per_layer / 2.0f) * (k + 1));
                boundry_atan_y_z[k] = M_PI * 2.0f / cloud_num_per_map[k];
            }
            boundry_atan_y_z[layers_per_map - 1] = M_PI * 2.0f / cloud_num_per_map[layers_per_map - 1];
            
        }

        void time_count(std::string filename, void (*func)(void)){
            clock_t t = clock();
            func();
            double time = (double)(clock() - t) / CLOCKS_PER_SEC;
            std::cout << "time cost of one process is : " << "\t" << time << std::endl;
        }

        void check_cloud(const ros::TimerEvent& event){
            for(auto p : map_list_kd_){
               fprintf(record_file_, "%d,", p->validnum());
            }
            fprintf(record_file_, "\b\n");
            
        }

        void check_cloud(float time_cost){
            for(auto p : map_list_kd_){
               fprintf(record_file_, "%d,", p->validnum());
            }
            fprintf(record_file_, "%0.3f", time_cost);
            fprintf(record_file_, "\b\n");
    
        }
        // 定时任务，处理点云队列
        // TODO 取出点云中的离群点，参考LOAM
        void process(const ros::TimerEvent& event){
            if(cloud_queue_.size() > 1){
                ROS_INFO("process once\n");
                pcl::PointCloud<pcl::PointXYZI>::Ptr cl(new pcl::PointCloud<pcl::PointXYZI>);
                *cl = *(cloud_queue_.front().cloud);
                cloud_queue_.pop();
                *cl += *(cloud_queue_.front().cloud);
                cloud_queue_.pop();
                // auto start = chrono::high_resolution_clock::now();
                // auto start = ros::Time::now();
                processCloud2(cl);
                // auto end      = chrono::high_resolution_clock::now();
                // float time = float(chrono::duration_cast<chrono::microseconds>(end - start).count());
                // check_cloud(time);
                // ROS_INFO(" process time : %lf\n", time);
            }
        }

        void cloudLivxoCB(sensor_msgs::PointCloud2::ConstPtr msg_cloud){
            // ROS_INFO("*********************************");
            // ROS_INFO("time 1 : %lf", ros::Time::now().toSec());
            pcl::PointCloud<pcl::PointXYZI>::Ptr pcl_cloud(new pcl::PointCloud<pcl::PointXYZI>);
            pcl::fromROSMsg(*msg_cloud, *pcl_cloud);
            cloudFrame frame;
            frame.cloud = pcl_cloud;
            frame.cloud_size = pcl_cloud->size();
            cloud_queue_.push(frame);
            // ROS_INFO("queue size : %ld ", cloud_queue_.size());
            if(cloud_queue_.size() >= 10) {
                cloud_queue_.pop();
            }
            // ROS_INFO("time 2 : %lf", ros::Time::now().toSec());
            // clock_t t = clock();0
            sensor_msgs::PointCloud2 msg_map(*msg_cloud);
            msg_map.header = std_msgs::Header();
            msg_map.header.frame_id = "livox_frame";
            pub_scan_.publish(msg_map);
            processCloud(pcl_cloud);
            // double time = (double)(clock() - t) / CLOCKS_PER_SEC;
            // fprintf(record_file_t_, "%lf\n", time);
        }

        void processCloud(pcl::PointCloud<pcl::PointXYZI>::Ptr in_cloud){
            pcl::PointCloud<pcl::PointXYZI> cl;
            vox_filter_->setInputCloud(in_cloud);
            vox_filter_->filter(cl);

            size_t s = cl.points.size();
            for(size_t i=0; i < s; i++){
                auto p = cl.points[i];
                size_t ind = subMapInd(p.x, p.y, p.z);
                // ROS_INFO("time 3 : %lf, ind : %ld", ros::Time::now().toSec(), ind);
                // std::cout << p.intensity << std::endl;
                if((p.intensity < intensity_thresh_1) || p.intensity > intensity_thresh_2)
                this->map_list_[ind]->push_back(p);
                // ROS_INFO("time 4 : %lf", ros::Time::now().toSec());
            }
            // pcl::PointCloud<pcl::PointXYZI> visual_map;
            // visual_map.clear();
            for(size_t i=0; i < cloud_num_total; i++){
                vox_filter_->setInputCloud(map_list_[i]);
                vox_filter_->filter(*map_list_[i]);
                // visual_map += *map_list_[i];
            }
            // // ROS_INFO("map size %ld", visual_map.size());
            // sensor_msgs::PointCloud2 msg_map;
            // msg_map.header = std_msgs::Header();
            // msg_map.header.frame_id = "map_s";
            // pub_scan_.publish(msg_map);
        }

        // 队列处理函数
        void processCloud2(pcl::PointCloud<pcl::PointXYZI>::Ptr &in_cloud){
            size_t s = in_cloud->points.size();
            
            for(size_t i=0; i < s; i++){
                auto p = in_cloud->points[i];
                size_t ind = subMapInd(p.x, p.y, p.z);
                if((p.intensity < intensity_thresh_1) || p.intensity > intensity_thresh_2){
                    this->sub_map_buffs_[ind].push_back(p);
                }
            }
            
            for(size_t i = 0; i < cloud_num_total; i++){
                if(map_list_kd_[i]->size() > 0 && this->sub_map_buffs_[i].size() > 0){
                    map_list_kd_[i]->Add_Points(this->sub_map_buffs_[i], true);
                } else if (map_list_kd_[i]->size() <= 0 && this->sub_map_buffs_[i].size() > 0){
                    map_list_kd_[i]->Build(this->sub_map_buffs_[i]);
                }
            }
        }

        // 可视化线程
        void visualThread(const ros::TimerEvent& event){
            static long int map_points_size = 0;
            map_points_size = 0;
            long int last_size = map_points_size;
            // std::cout << map_list_kd_[0]->PCL_Storage.size() << std::endl;
            pcl::PointCloud<pcl::PointXYZI> visual_map;
            visual_map.clear();
            for(size_t i=0; i < cloud_num_total; i++){
                visual_map += *map_list_[i];
                map_points_size += map_list_[i]->size();
            }
            // ROS_INFO("map size %ld", visual_map.size());
            sensor_msgs::PointCloud2 msg_map;
            pcl::toROSMsg(visual_map, msg_map);
            msg_map.header = std_msgs::Header();
            msg_map.header.frame_id = "map_s";
            pub_map_visual_split_.publish(msg_map);
        }

        int subMapInd(float x, float y, float z){
            // x=y=0的情况特殊处理
            if(y*y < 0.01 && z*z < 0.01) return 0;
            // 根据新的分层策略修改索引方法
            float dis_y_z = sqrtf32(z*z + y*y);
            float tan_fov2 = dis_y_z / x;

            // if(tan_fov2 <= boundry_tan_yz_x[0]) return 0;

            // 求层号
            int fovInd = layers_per_map - 1;
            for(size_t k=0; k < layers_per_map-1; k++){
                if (tan_fov2 <= boundry_tan_yz_x[k]){
                    fovInd = k;
                    break;
                }
            }
            
            // 求层内子点云编号
            float d_yz = atan2(y, z);
            // ROS_INFO("d_yz : %f, boundry_atan_y_z[fovInd] : %f", d_yz, boundry_atan_y_z[fovInd]);
            int circleInd = (int)ceil((d_yz + M_PI) / boundry_atan_y_z[fovInd]);
            if(circleInd >= cloud_num_per_map[fovInd]) circleInd = cloud_num_per_map[fovInd];

            // ROS_INFO("fovInd : %d, circleInd : %d", fovInd, circleInd);
            // 上一层的最大索引加上这层的编号，即对应子点云的总编号
            return min_index_submap[fovInd] + circleInd - 1;
        }

    private:
        ros::NodeHandle nh_;
        ros::Timer timer;
        ros::Subscriber sub_livox_cloud_;
        ros::Publisher pub_scan_;
        ros::Publisher pub_map_visual_split_;
        std::string cloud_topic_name_;
        pcl::PointCloud<pcl::PointXYZI>::Ptr map_;
        std::queue<cloudFrame> cloud_queue_;
        int cloud_num_total;
        std::vector<pcl::PointCloud<pcl::PointXYZI>::Ptr> map_list_;

        std::vector<KD_TREE<pcl::PointXYZI>::PointVector> sub_map_buffs_;
        std::vector<KD_TREE<pcl::PointXYZI>::Ptr> map_list_kd_;
        ros::Timer map_timer, visual_timer;

        pcl::VoxelGrid<pcl::PointXYZI>::Ptr vox_filter_;

        // EVALUATE
        FILE * record_file_;
        FILE * record_file_t_;
};

int main(int argc, char **argv){
    ros::init(argc, argv, "test_node");
    ROS_INFO("Start node");

    mapMaintainer m("livox/lidar");
    ros::spin();

    std::cout << "#### Node Exited ####" << std::endl;
    return 0;
}